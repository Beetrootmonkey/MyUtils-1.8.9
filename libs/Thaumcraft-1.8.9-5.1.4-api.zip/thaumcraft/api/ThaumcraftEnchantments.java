package thaumcraft.api;

public class ThaumcraftEnchantments {

	//Enchantment references
	public static int HASTE;
	public static int REPAIR;

}
