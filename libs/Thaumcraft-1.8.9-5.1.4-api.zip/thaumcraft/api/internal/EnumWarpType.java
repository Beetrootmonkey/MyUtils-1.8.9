package thaumcraft.api.internal;

public enum EnumWarpType {
	PERMANENT, NORMAL, TEMPORARY;
}
